"""Scripts package for TabPFN."""

from __future__ import annotations